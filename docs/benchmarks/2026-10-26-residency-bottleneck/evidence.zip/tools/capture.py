import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts/measure'))
from measure_render_optimizations import make_config,CAMERAS

NSYS=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.3.2/target-windows-x64/nsys.exe')
EXE=ROOT/'build-release-dyn-clang64/deren.exe'
ASSET=Path('D:/deren-assets/bistro/textured-verified/bistro-core-mr.gltf')
OUT=ROOT/'tmp/residency-nsys-20261026'
OUT.mkdir(exist_ok=True)
for case in sys.argv[1:]:
    camera,mode=case.split('-')
    enabled=mode=='selective'
    run=OUT/case
    run.mkdir(exist_ok=False)
    config=run/'config.toml'
    make_config(config,ASSET,EXE.parent/'shaders',run,'no_optimizations')
    config.write_text(config.read_text().replace('[render]\n','[render]\nanimation_time = 0.0\n')
        .replace('visibility_buffer = true',f'visibility_buffer = true\nvisibility_texture_streaming = {str(enabled).lower()}'))
    env={k:v for k,v in os.environ.items() if not k.startswith('DEREN_')}
    env['PATH']='C:/msys64/clang64/bin;'+env.get('PATH','')
    env['DEREN_BENCH_FRAME_TRACE']=str(run/'frames.csv')
    command=[str(NSYS),'profile','--trace=vulkan','--vulkan-gpu-workload=individual',
        '--sample=none','--cpuctxsw=none','--show-output=false','--export=sqlite',
        '--output='+str(run/'profile'),'--kill=false',str(EXE),'--config',str(config),
        '--capture-frames','360',f'--capture-camera={CAMERAS["near"]}']
    if camera=='sweep':command+=['--capture-sweep','.5']
    manifest=dict(command=command,exe_sha256=hashlib.sha256(EXE.read_bytes()).hexdigest(),
        frames=360,warmup=120,trace='Vulkan individual GPU workloads; CPU sampling/context-switch tracing disabled',
        warning='Profiler timings are diagnostic and may include profiler overhead; do not substitute for unprofiled benchmark FPS.')
    (run/'manifest.json').write_text(json.dumps(manifest,indent=2))
    started=time.perf_counter()
    with (run/'profiler.log').open('wb') as output:
        result=subprocess.run(command,cwd=run,env=env,stdout=output,stderr=subprocess.STDOUT,
            timeout=1200,creationflags=subprocess.CREATE_NO_WINDOW)
    print(case,'exit',result.returncode,'elapsed',round(time.perf_counter()-started,1),flush=True)
    if result.returncode:
        print((run/'profiler.log').read_text(errors='replace')[-4000:],flush=True)
        raise SystemExit(result.returncode)
