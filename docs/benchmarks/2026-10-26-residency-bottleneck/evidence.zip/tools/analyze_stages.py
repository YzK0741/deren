import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics as st

ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'tmp/residency-stage-profile-20261026'
OUT=ROOT/'docs/benchmarks/2026-10-26-residency-bottleneck'
OUT.mkdir(parents=True,exist_ok=True)


def percentile(values,p):
    values=sorted(values);x=(len(values)-1)*p;lo=math.floor(x)
    return values[lo]+(values[math.ceil(x)]-values[lo])*(x-lo)


def stats(values):
    return dict(mean=st.mean(values),median=st.median(values),p95=percentile(values,.95),
                p99=percentile(values,.99),maximum=max(values))


def correlation(a,b):
    ma,mb=st.mean(a),st.mean(b)
    return sum((x-ma)*(y-mb) for x,y in zip(a,b))/math.sqrt(sum((x-ma)**2 for x in a)*sum((y-mb)**2 for y in b))


result={}
for name in ('near-eager','near-selective','sweep-eager','sweep-selective'):
    run=DATA/name
    with (run/'frames.csv').open() as stream:frames=list(csv.DictReader(stream))
    with (run/'gpu-stages.csv').open() as stream:gpu=list(csv.DictReader(stream))
    manifest=json.loads((run/'manifest.json').read_text())
    assert hashlib.sha256(Path(manifest['command'][0]).read_bytes()).hexdigest()==manifest['exe_sha256']
    assert len(frames)==361 and len(gpu)==359
    assert [int(r['sample']) for r in gpu]==list(range(1,360))
    assert all(math.isfinite(float(r[k])) and float(r[k])>=0 for r in gpu for k in r)
    log=(run/'deren-debug.log').read_text(errors='replace')
    assert not re.search(r'VUID-|Validation Error|SYNC-HAZARD|\[ERROR\]|post graph: recording refused|panic|GPU timing mark .*refused',log)
    steady_frames=frames[120:360]
    gpu=gpu[120:]
    intervals=[float(r['interval_ms']) for r in steady_frames]
    data=dict(frame=stats(intervals),fps=1000/st.mean(intervals),
              gpu={k:stats([float(r[k]) for r in gpu]) for k in gpu[0] if k not in ('sample','frame_ms','cpu_prepare_ms')},
              measured_gpu_frames=len(gpu),host_frames=len(steady_frames))
    # CPU phase reports are non-overlapping 60-frame windows; discard first two warm-up windows.
    windows=[]
    for line in log.splitlines():
        if 'cpu frame phases (avg of 60 frames):' in line:
            fields=re.findall(r'([a-zA-Z*-]+) ([0-9.eE+-]+) ms',line)
            windows.append(dict((k,float(v)) for k,v in fields))
    assert len(windows)>=6
    data['cpu_phase_means_ms']={k:st.mean(r[k] for r in windows[2:6]) for k in windows[2]}
    if name.endswith('selective'):
        patterns={
            'checkpoint':(r'profile checkpoint (\d+) submit (\S+) wait (\S+) recycle (\S+)',('submit','wait','recycle')),
            'update':(r'profile residency update (\d+) demand (\S+) scan (\S+) bind (\S+) account (\S+) upload (\d+) deferred (\d+)',('demand','scan','bind','account','upload_bytes','deferred')),
            'graph':(r'profile graph (\d+) partition (\S+) prefix (\S+) checkpoint (\S+) update (\S+) suffix (\S+)',('partition','prefix','checkpoint','update','suffix')),
        }
        indexed={}
        for kind,(pattern,fields) in patterns.items():
            rows={int(m[0]):dict(zip(fields,map(float,m[1:]))) for m in re.findall(pattern,log)}
            assert set(rows)==set(range(1,362)),(name,kind,len(rows))
            indexed[kind]=rows
            data['cpu_'+kind]={field:stats([rows[i][field] for i in range(121,361)]) for field in fields}
        joins=[]
        for i in range(121,361):
            joins.append(dict(frame=i,frame_ms=float(frames[i-1]['interval_ms']),**indexed['update'][i],
                              checkpoint_wait=indexed['checkpoint'][i]['wait'],prefix_record=indexed['graph'][i]['prefix']))
        data['longest_frames']=sorted(joins,key=lambda r:r['frame_ms'],reverse=True)[:12]
        data['upload_frames']=sum(r['upload_bytes']>0 for r in joins)
        data['steady_upload_bytes']=sum(r['upload_bytes'] for r in joins)
        if name.startswith('sweep'):
            data['bind_vs_frame_pearson']=correlation([r['bind'] for r in joins],[r['frame_ms'] for r in joins])
            data['upload_bytes_vs_bind_pearson']=correlation([r['upload_bytes'] for r in joins],[r['bind'] for r in joins])
        with (OUT/(name+'-joined.csv')).open('w',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=joins[0].keys());writer.writeheader();writer.writerows(joins)
    result[name]=data

(OUT/'analysis.json').write_text(json.dumps(result,indent=2))
for name,r in result.items():
    print(name,'FPS',round(r['fps'],2),'frame mean',round(r['frame']['mean'],3),'p99',round(r['frame']['p99'],3))
    print('GPU means',{k:round(r['gpu'][k]['mean'],4) for k in ('visibility raster','residency feedback','residency gap','scene','lighting')})
    print('CPU phase means',r['cpu_phase_means_ms'])
    if 'cpu_checkpoint' in r:
        print('CPU checkpoint means',{k:round(v['mean'],4) for k,v in r['cpu_checkpoint'].items()})
        print('CPU update means',{k:round(v['mean'],4) for k,v in r['cpu_update'].items()})
        print('CPU graph means',{k:round(v['mean'],4) for k,v in r['cpu_graph'].items()})
        print('Largest frame',r['longest_frames'][0])
        print('correlation',r.get('bind_vs_frame_pearson'),r.get('upload_bytes_vs_bind_pearson'))
print('Stage analysis verified.')
