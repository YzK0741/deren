import json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

root=Path(__file__).resolve().parents[2]
out=root/'docs/benchmarks/2026-10-26-residency-bottleneck'
data=json.loads((out/'analysis.json').read_text())
image=Image.new('RGB',(1400,600),'white');draw=ImageDraw.Draw(image)
font=lambda size:ImageFont.truetype('C:/Windows/Fonts/arial.ttf',size)
ink='#203044';muted='#607080'
draw.text((35,20),'Where frame time goes: CPU / GPU overlap lost at checkpoint',fill=ink,font=font(27))
draw.text((35,64),'Bistro 1280 x 720 | Diagnostic build | 120 warm-up + 240 host frame samples per case',fill=muted,font=font(18))
colors=('#3879b7','#a6b1bc','#df7b29','#9a68ad')
labels=('Other CPU work, including recording','Frame-start wait','Checkpoint wait','Lazy bind / upload path')
for i,(label,color) in enumerate(zip(labels,colors)):
    x=35+(i%2)*660;y=105+(i//2)*31
    draw.rectangle((x,y,x+18,y+18),fill=color);draw.text((x+28,y-2),label,fill=ink,font=font(18))
left,right,top,bottom=220,1335,207,473
for n in range(9):
    x=left+n/8*(right-left);draw.line((x,top,x,bottom),fill='#e8edf1')
    draw.text((x,bottom+9),str(n*5),fill=muted,font=font(16),anchor='mt')
for row,(name,label) in enumerate((('near-eager','Fixed / off'),('near-selective','Fixed / on'),('sweep-eager','Moving / off'),('sweep-selective','Moving / on'))):
    r=data[name];total=r['frame']['mean'];pace=r['cpu_phase_means_ms']['pace']
    wait=r.get('cpu_checkpoint',{}).get('wait',{}).get('mean',0)
    bind=r.get('cpu_update',{}).get('bind',{}).get('mean',0)
    values=(total-pace-wait-bind,pace,wait,bind)
    y=top+row*66+8;draw.text((left-20,y+20),label,fill=ink,font=font(20),anchor='rm')
    x=left
    for value,color in zip(values,colors):
        end=x+value/40*(right-left);draw.rectangle((x,y,end,y+39),fill=color)
        if value>2:draw.text(((x+end)/2,y+20),f'{value:.1f}',fill='white',font=font(18),anchor='mm')
        x=end
    draw.text((x+8,y+20),f'{total:.1f}',fill=ink,font=font(17),anchor='lm')
draw.text((left,515),'Mean host frame interval (ms). GPU raster remains approximately 19.2-19.3 ms in all four cases.',fill=ink,font=font(18))
draw.text((35,556),'Checkpoint wait includes GPU work, not just idle. Bind includes allocation, host image copy and synchronization.',fill=muted,font=font(17))
image.save(out/'frame-budget.png')
print('Frame budget figure created.')
