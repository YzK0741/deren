import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts/measure'))
from measure_render_optimizations import make_config,CAMERAS

EXE=ROOT/'tmp/residency-profile-bin/deren.exe'
ASSET=Path('D:/deren-assets/bistro/textured-verified/bistro-core-mr.gltf')
OUT=ROOT/'tmp/residency-stage-profile-20261026'
OUT.mkdir(exist_ok=True)
for case in sys.argv[1:]:
    camera,mode=case.split('-')
    enabled=mode=='selective'
    run=OUT/case;run.mkdir(exist_ok=False)
    config=run/'config.toml'
    make_config(config,ASSET,EXE.parent/'shaders',run,'no_optimizations')
    config.write_text(config.read_text().replace('[render]\n','[render]\nanimation_time = 0.0\n')
        .replace('visibility_buffer = true',f'visibility_buffer = true\nvisibility_texture_streaming = {str(enabled).lower()}'))
    env={k:v for k,v in os.environ.items() if not k.startswith('DEREN_')}
    env['PATH']='C:/msys64/clang64/bin;'+env.get('PATH','')
    env['DEREN_BENCH_FRAME_TRACE']=str(run/'frames.csv')
    env['DEREN_GAUSSIAN_BENCHMARK']=str(run/'gpu-stages.csv')
    env['DEREN_PROFILE_RESIDENCY']='1'
    command=[str(EXE),'--config',str(config),'--capture-frames','360',f'--capture-camera={CAMERAS["near"]}']
    if camera=='sweep':command+=['--capture-sweep','.5']
    manifest=dict(command=command,exe_sha256=hashlib.sha256(EXE.read_bytes()).hexdigest(),
        frames=360,warmup=120,notes='Diagnostic build: 3 additional GPU timestamps, optional per-frame CPU stage logs. No streaming policy change.')
    (run/'manifest.json').write_text(json.dumps(manifest,indent=2))
    started=time.perf_counter()
    with (run/'stdout.log').open('wb') as output:
        result=subprocess.run(command,cwd=run,env=env,stdout=output,stderr=subprocess.STDOUT,
            timeout=900,creationflags=subprocess.CREATE_NO_WINDOW)
    log=(run/'deren-debug.log').read_text(errors='replace')
    errors=re.findall(r'VUID-|Validation Error|SYNC-HAZARD|\[ERROR\]|post graph: recording refused|panic|GPU timing mark .*refused',log)
    assert result.returncode==0 and not errors,(case,result.returncode,errors[:4])
    with (run/'frames.csv').open() as stream:frames=list(csv.DictReader(stream))
    with (run/'gpu-stages.csv').open() as stream:stages=list(csv.DictReader(stream))
    assert len(frames) in (360,361) and len(stages)>=350
    assert 'residency feedback' in stages[0] and 'residency gap' in stages[0]
    print(case,'frames',len(frames),'GPU rows',len(stages),'elapsed',round(time.perf_counter()-started,1),flush=True)
