import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parents[2]
build=root/'build-release-dyn-clang64'
backup=root/'tmp/residency-profile-original'
dest=root/'tmp/residency-profile-bin'
dest.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']='C:/msys64/clang64/bin;'+env.get('PATH','')
try:
    with (root/'tmp/residency-profile-build-final.log').open('wb') as log:
        result=subprocess.run(['C:/msys64/clang64/bin/cmake.exe','--build',str(build),'--target','deren','-j','14'],
                              cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError('Profile build failed; inspect build log')
    for name in json.loads((backup/'manifest.json').read_text()):
        shutil.copy2(build/name,dest/name)
    shutil.copytree(build/'shaders',dest/'shaders')
    print('Profile build prepared:',hashlib.sha256((dest/'deren.exe').read_bytes()).hexdigest(),flush=True)
finally:
    original=json.loads((backup/'manifest.json').read_text())
    for name,digest in original.items():
        shutil.copy2(backup/name,build/name)
        assert hashlib.sha256((build/name).read_bytes()).hexdigest()==digest
    print('Original benchmark executable/DLLs restored and verified.',flush=True)
