import difflib
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root=Path(__file__).resolve().parents[2]
out=root/'docs/benchmarks/2026-10-26-residency-bottleneck'
source=root/'tmp/residency-profile-instrumented-source'
patch=[];hashes={}
for p in source.rglob('*'):
    if not p.is_file():continue
    relative=p.relative_to(source)
    before=(root/relative).read_text()
    after=p.read_text()
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
        fromfile='a/'+relative.as_posix(),tofile='b/'+relative.as_posix()))
    hashes[relative.as_posix()]=dict(current_sha256=hashlib.sha256((root/relative).read_bytes()).hexdigest(),
        diagnostic_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(out/'instrumentation.patch').write_text(''.join(patch))
(out/'source-identity.json').write_text(json.dumps(hashes,indent=2))
identity=json.loads((root/'tmp/residency-review-pinned-20261026/artifact-identity.json').read_text())
for name,value in identity.items():
    if isinstance(value,dict):assert hashlib.sha256((root/name).read_bytes()).hexdigest()==value['sha256'],name
assert 'DEREN_PROFILE_RESIDENCY' not in ''.join((root/name).read_text() for name in hashes)
assert 'residency_feedback_begin' not in (root/'source/engine/runtime/runtime.declarations.cppm').read_text()
with zipfile.ZipFile(out/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    parent=root/'tmp/residency-stage-profile-20261026'
    for p in parent.rglob('*'):
        if p.is_file() and p.suffix in ('.csv','.json','.toml','.log'):
            archive.write(p,Path('measurements')/p.relative_to(parent))
    for p in source.rglob('*'):
        if p.is_file():archive.write(p,Path('diagnostic-source')/p.relative_to(source))
    for p in (root/'tmp/residency-profile-tools').glob('*.py'):
        archive.write(p,Path('tools')/p.name)
    for name in ('residency-profile-build.log','residency-profile-build-final.log'):
        archive.write(root/'tmp'/name,Path('build-logs')/name)
with zipfile.ZipFile(out/'evidence.zip') as archive:
    assert archive.testzip() is None
    count=len(archive.namelist())
print('Packaged',count,'evidence files. Original 71 build artifacts unchanged; temporary measurement hooks removed from primary sources.')
