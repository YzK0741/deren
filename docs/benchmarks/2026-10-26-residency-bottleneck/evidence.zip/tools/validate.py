import json
import os
from pathlib import Path
import re
import subprocess

root=Path(__file__).resolve().parents[2]
parent=root/'tmp/residency-stage-profile-20261026'
run=parent/'near-selective-validation';run.mkdir(exist_ok=False)
config=run/'config.toml'
config.write_text((parent/'near-selective/config.toml').read_text()
    .replace('validation_layers = false','validation_layers = true')
    .replace(str(parent/'near-selective').replace('\\','/'),str(run).replace('\\','/')))
env={k:v for k,v in os.environ.items() if not k.startswith('DEREN_')}
env['PATH']='C:/msys64/clang64/bin;'+env.get('PATH','')
env['DEREN_PROFILE_RESIDENCY']='1'
env['DEREN_GAUSSIAN_BENCHMARK']=str(run/'gpu-stages.csv')
with (run/'stdout.log').open('wb') as stream:
    result=subprocess.run([str(root/'tmp/residency-profile-bin/deren.exe'),'--config',str(config),
        '--capture-frames','16','--capture-camera=35,8,42,0,-88,0'],cwd=run,env=env,
        stdout=stream,stderr=subprocess.STDOUT,timeout=600,creationflags=subprocess.CREATE_NO_WINDOW)
log=(run/'deren-debug.log').read_text(errors='replace')
errors=re.findall(r'VUID-|Validation Error|SYNC-HAZARD|\[ERROR\]|post graph: recording refused|panic|GPU timing mark .*refused',log)
assert result.returncode==0 and not errors,(result.returncode,errors[:4])
assert 'validation layers enabled' in log
assert len(list(run.glob('screenshot_*.png')))==1
(run/'validation.json').write_text(json.dumps(dict(exit_code=result.returncode,validation_enabled=True,
    errors=errors,capture=True),indent=2))
print('Instrumented build: validation enabled, no diagnostics or refused timing marks, capture complete.')
